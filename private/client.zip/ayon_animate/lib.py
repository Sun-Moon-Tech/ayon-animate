import re

import ayon_api

from ayon_core.lib import prepare_template_data
from ayon_core.pipeline import (
    AutoCreator,
    CreatedInstance
)
from ayon_animate import api
from ayon_animate.api.pipeline import cache_and_get_instances


class FLAutoCreator(AutoCreator):
    """Generic autocreator to extend."""
    skip_discovery = True
    settings_category = "animate"

    # Settings based attribute
    active_on_create = True

    def get_instance_attr_defs(self):
        return []

    def collect_instances(self):
        for instance_data in cache_and_get_instances(self):
            creator_id = instance_data.get("creator_identifier")

            if creator_id == self.identifier:
                instance = CreatedInstance.from_existing(
                    instance_data, self
                )
                self._add_instance_to_context(instance)

    def update_instances(self, update_list):
        self.log.debug("update_list:: {}".format(update_list))
        for created_inst, _changes in update_list:
            api.stub().imprint(created_inst.get("instance_id"),
                               created_inst.data_to_store())

    def create(self, options=None):
        existing_instance = None
        for instance in self.create_context.instances:
            if instance.product_type == self.product_type:
                existing_instance = instance
                break

        context = self.create_context
        project_name = context.get_current_project_name()
        folder_path = context.get_current_folder_path()
        task_name = context.get_current_task_name()
        host_name = context.host_name

        if existing_instance is None:
            existing_instance_folder = None
        else:
            existing_instance_folder = existing_instance["folderPath"]

        if existing_instance is None:
            folder_entity = ayon_api.get_folder_by_path(
                project_name, folder_path
            )
            task_entity = ayon_api.get_task_by_name(
                project_name, folder_entity["id"], task_name
            )
            product_name = self.get_product_name(
                project_name=project_name,
                folder_entity=folder_entity,
                task_entity=task_entity,
                variant=self.default_variant,
                host_name=host_name,
            )
            data = {
                "folderPath": folder_path,
                "task": task_name,
                "variant": self.default_variant
            }
            data.update(self.get_dynamic_data(
                project_name,
                folder_entity,
                task_entity,
                self.default_variant,
                host_name,
                None
            ))

            if not self.active_on_create:
                data["active"] = False

            new_instance = CreatedInstance(
                product_base_type=self.product_base_type,
                product_type=self.product_base_type,
                product_name=product_name,
                data=data,
                creator=self,
            )
            self._add_instance_to_context(new_instance)
            api.stub().imprint(new_instance.get("instance_id"),
                               new_instance.data_to_store())

        elif (
            existing_instance_folder != folder_path
            or existing_instance["task"] != task_name
        ):
            folder_entity = ayon_api.get_folder_by_path(
                project_name, folder_path
            )
            task_entity = ayon_api.get_task_by_name(
                project_name, folder_entity["id"], task_name
            )
            product_name = self.get_product_name(
                project_name=project_name,
                folder_entity=folder_entity,
                task_entity=task_entity,
                variant=self.default_variant,
                host_name=host_name,
            )
            existing_instance["folderPath"] = folder_path
            existing_instance["task"] = task_name
            existing_instance["productName"] = product_name


def clean_product_name(product_name):
    """Clean all variants leftover {layer} from product name."""
    dynamic_data = prepare_template_data({"layer": "{layer}"})
    for value in dynamic_data.values():
        if value in product_name:
            product_name = (
                product_name
                .replace(value, "")
                .replace("__", "_")
                .replace("..", ".")
            )
    # clean trailing separator as Main_
    pattern = r'[\W_]+$'
    replacement = ''
    return re.sub(pattern, replacement, product_name)
