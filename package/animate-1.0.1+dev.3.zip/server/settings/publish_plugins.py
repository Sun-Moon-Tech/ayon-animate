from ayon_server.settings import (
    BaseSettingsModel,
    SettingsField,
    task_types_enum
)



class RenderSourceProfile(BaseSettingsModel):
    _layout = "expanded"
    task_types: list[str] = SettingsField(
        default_factory=list,
        title="Task types",
        enum_resolver=task_types_enum
    )
    export_swf: bool = SettingsField(True, title="Export SWF")
    render_source: str = SettingsField(
        "",
        title="Render source",
        description="Render source for the given task type(s). Expects a value from: movie, h264, png_sequence"
    )

# class RenderSourceModel(BaseSettingsModel):
#     render_source_profile: RenderSourceProfile = SettingsField(
#         default_factory=RenderSourceProfile,
#         title="Task profiles",
#     ) 

class ExtractRenderSettings(BaseSettingsModel):
    """Animate Render Settings."""

    swf_tasks: list[str] = SettingsField(
        default_factory=list,
        title="SWF tasks",
        description="List of tasks to render swfs on publish.",
        enum_resolver=task_types_enum
    )

    render_source: str = SettingsField(
        "",
        title="Default render source",
        description="Default render source if not specified for the given task. Expects a value from: movie, h264, png_sequence"
    )

    task_render_profiles: list[RenderSourceProfile] = SettingsField(
        default_factory=list,
        title="Task profiles",
        description="Profiles for task-specific render settings."
    ) 
    # task_render_profiles : RenderSourceModel = SettingsField(
    #     default_factory=RenderSourceModel,
    #     title="Task render profiles",
    #     description="Task-specific render profiles."
    # )


class PublishPlugins(BaseSettingsModel):
    ExtractRender: ExtractRenderSettings = SettingsField(
        default_factory=ExtractRenderSettings,
        title="Extract Render Settings"
    )

DEFAULT_PUBLISH_SETTINGS = {
    "ExtractRender": {
        "swf_tasks": ["animation"],
        "render_source" : "h264",
        "task_render_profiles" : [
            {
                "task_types":["animation","animatic"],
                "export_swf":True,
                "render_source":"h264"
            },
            {
                "task_types":["design","rigging"],
                "export_swf":False,
                "render_source":"movie"
            }
        ]
    }
}