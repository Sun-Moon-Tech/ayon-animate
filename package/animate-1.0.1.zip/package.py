name = "animate"
title = "Animate"
version = "1.0.1"
app_host_name = "animate"
client_dir = "ayon_animate"
project_can_override_addon_version = True

ayon_server_version = ">=1.1.2"
ayon_required_addons = {
    "core": ">1.4.1",
}
ayon_compatible_addons = {}
